<?php
session_start();

// Database connection
$servername = "localhost";   // Your DB server
$username   = "root";        // Your DB username
$password   = "";            // Your DB password
$dbname     = "gatepass";    // ✅ Database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo "❌ Database connection failed!";
    exit();
}

// Process login form
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['username']);
    $pass  = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM r_db WHERE R_Email = ? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();

        // If you stored passwords hashed (recommended)
        if (password_verify($pass, $row['Password'])) {
            $_SESSION['R_Email'] = $row['R_Email'];
            echo "✅ Login successful";
        } 
        // If passwords are plain text (not secure)
        elseif ($pass === $row['Password']) {
            $_SESSION['R_Email'] = $row['R_Email'];
            echo "✅ Login successful";
        } else {
            echo "❌ Invalid password";
        }
    } else {
        echo "⚠️ No user found with that email";
    }

    $stmt->close();
}

$conn->close();
?>
